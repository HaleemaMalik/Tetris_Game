/* NAME: HALEEMA TAHIR MALIK
 * ROLL NO: 22I-0937
 * BSCS PF PROJECT*/

/* PROGRAMMING FUNDAMENTAL'S PROJECT FOR FALL 2022 BS(CS)
 * Shape of each piece is represented by rows in the array.
 * TIP: Name the array what is already been coded to avoid any unwanted errors.
 */

int BLOCKS[7][4]=
        {
                {1,3,5,7},			//I
                {3,5,6,7},			//J
                {0,1,3,5},			//L
                {0,1,2,3},			//O
                {0,2,3,5},			//S
                {3,4,5,6},			//Z
                {3,4,5,7}			//T

        };

